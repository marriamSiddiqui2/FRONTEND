 import React, { useState } from 'react'
 import './Sidebar.css'
 import { assets } from '../../assets/assets'
 const Sidebar = () => {
       
    const [marriam, setMarriam]= useState (false)



   return (
     <div className='sidebar'>
           <div className="top">  {/*TOPPP start here */}
               <img onClick={()=>setMarriam(prev=>!prev)} className='menu' src={assets.menu_icon} alt="MENUICON" />
           <div className="new-chat">
               <img src={assets.plus_icon} alt="PLUSICON" />
               {marriam ?<p>NEW CHAT</p>: null}
           </div>
           {marriam ?
           <div className="recent">
            <p className="recent-title">
              Recent
            </p>
            <div className="recent-entry"><img src={assets.message_icon} alt="msgIcon" />
            <p>what is react ...</p>
            </div>
           </div>
           : null }
           </div>                   {/*TOPPP ENDS here */}                     
           <div className="botton recent-entry"> {/*ahhh bottom start here */}
           <div className="bottom-item">
            <img src={assets.question_icon} alt="questIcon" />
            <p>Help</p>
           </div>
           <div className="bottom-item">
            <img src={assets.history_icon} alt="hisIcon" />
            <p>Activities</p>
           </div>
           <div className="bottom-item">
            <img src={assets.setting_icon} alt="setIcon" />
            <p>Settings</p>
           </div>
           </div>                   {/* bottom end here  */}
     </div>
   )
   
  }
 export default Sidebar
 